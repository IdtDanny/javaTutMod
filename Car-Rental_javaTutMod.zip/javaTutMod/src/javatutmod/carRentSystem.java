
package javatutmod;

import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class carRentSystem extends JFrame {

    private JTextField name, phone, email, id, address, model;
    private JComboBox<String> gender, brand, paymethod, cost, duration;
    private JButton jButton1;

    public carRentSystem() {
        initComponents();
    }

    private void initComponents() {
        // Colors
        Color bgColor = new Color(205, 212, 225);
        Color headerColor = new Color(0, 102, 153);
        Color labelColor = new Color(0, 51, 102);
        Color buttonColor = new Color(0, 153, 153);

        // Frame settings
        setTitle("CAR RENTAL SYSTEM");
        setSize(550, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(bgColor);

        // Layout
        GridBagLayout layout = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        setLayout(layout);

        // Title label
        JLabel jLabel1 = new JLabel("CAR RENTAL SYSTEM");
        jLabel1.setFont(new Font("Segoe UI", Font.BOLD, 26));
        jLabel1.setForeground(headerColor);
        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        c.gridwidth = 2;
        c.insets = new Insets(20, 10, 20, 10);
        c.gridx = 0;
        c.gridy = 0;
        add(jLabel1, c);

        // Field labels and components
        String[] labels = {
            "Your Name:", "Permit ID:", "Phone:", "Email:", "Address:", "Gender:", "Car Brand:", "Car Model:", 
            "Duration:", "Cost:", "Pay Method:"
        };

        Component[] fields = new Component[labels.length];

        name = new JTextField(20);
        id = new JTextField(20);
        phone = new JTextField(20);
        email = new JTextField(20);
        address = new JTextField(20);
        gender = new JComboBox<>(new String[]{"--Select--", "Male", "Female"});
        brand = new JComboBox<>(new String[]{"--Select--", "Toyota", "Chevrolet", "Tesla", "Bmw", "Volkswagen", "Ford", "Mitsubishi", "Other"});
        model = new JTextField(20);
        duration = new JComboBox<>(new String[]{"--Select--", "1 Day", "2 Days", "3 Days", "4 Days", "5 Days", "1 Week", "1 Month"});
        cost = new JComboBox<>(new String[]{"--Select--", "1 Day - 40,000 Rwf", "2 Days - 70,000 Rwf", "3 Days - 100,000 Rwf", "4 Days - 120,000 Rwf", "5 Days - 150,000 Rwf", "1 Week - 200,000 Rwf", "1 Month - 600,000 Rwf"});
        paymethod = new JComboBox<>(new String[]{"--Select--", "MTN MOMO", "AIRTEL", "VISA CARD"});

        fields[0] = name;
        fields[1] = id;
        fields[2] = phone;
        fields[3] = email;
        fields[4] = address;
        fields[5] = gender;
        fields[6] = brand;
        fields[7] = model;
        fields[8] = duration;
        fields[9] = cost;
        fields[10] = paymethod;

        // Adding labels and fields to the form
        for (int i = 0; i < labels.length; i++) {
            JLabel lbl = new JLabel(labels[i]);
            lbl.setFont(new Font("Segoe UI", Font.PLAIN, 16));
            lbl.setForeground(labelColor);

            c.gridwidth = 1;
            c.gridx = 0;
            c.gridy = i + 1;
            c.anchor = GridBagConstraints.LINE_END;
            c.insets = new Insets(10, 10, 10, 10);
            add(lbl, c);

            c.gridx = 1;
            c.anchor = GridBagConstraints.LINE_START;
            add(fields[i], c);
        }

        // Save button
        jButton1 = new JButton("BOOK NOW");
        jButton1.setFont(new Font("Segoe UI", Font.BOLD, 18));
        jButton1.setBackground(buttonColor);
        jButton1.setForeground(Color.WHITE);
        jButton1.addActionListener(evt -> bookNow());
        c.gridx = 0;
        c.gridy = labels.length + 2;
        c.gridwidth = 2;
        c.anchor = GridBagConstraints.CENTER;
        c.insets = new Insets(25, 10, 20, 10);
        add(jButton1, c);
    }

    private void bookNow() {
        // Collect values from form
        String fullName = name.getText().trim();
        String Id = id.getText();
        String Email = email.getText().trim();
        String Phone = phone.getText();
        String Address = address.getText().trim();
        String Brand = brand.getSelectedItem().toString();
        String Model = model.getText().trim();
        String Gender = gender.getSelectedItem().toString();
        String Duration = duration.getSelectedItem().toString();
//        String costs = cost.getSelectedItem().toString();
        String costs = "0.00";
        String payMethod = paymethod.getSelectedItem().toString();

        // Setting the cost
        if (Duration.equals("1 Day")) { costs = "40000.0"; }
        if (Duration.equals("2 Days")) { costs = "70000.0"; }
        if (Duration.equals("3 Days")) { costs = "100000.0"; }
        if (Duration.equals("4 Days")) { costs = "120000.0"; }
        if (Duration.equals("5 Days")) { costs = "150000.0"; }
        if (Duration.equals("1 Week")) { costs = "200000.0"; }
        if (Duration.equals("1 Month")) { costs = "600000.0"; }
        // Validation checks
        if (fullName.isEmpty() || Id.isEmpty() || Email.isEmpty() || Phone.isEmpty() || Address.isEmpty() || Brand.equals("--Select--") || Model.isEmpty()
                || Gender.equals("--Select--") || Duration.equals("--Select--") || payMethod.equals("--Select--")) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields correctly.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Database Connection & Data Saving
//        CREATE DATABASE `car_rental`;
//
//        CREATE TABLE `booking` (
//                id INT PRIMARY KEY AUTO_INCREMENT,
//                name VARCHAR(50) NOT NULL,
//                permit VARCHAR(20) NOT NULL,
//                phone VARCHAR(12) NOT NULL,
//                email VARCHAR(50) NOT NULL,
//                address TEXT NOT NULL,
//                gender VARCHAR(15) NOT NULL,
//                brand VARCHAR(30) NOT NULL,
//                model VARCHAR(30) NOT NULL,
//                duration VARCHAR(30) NOT NULL,
//                cost INT(20) NOT NULL,
//                payment VARCHAR(20) NOT NULL
//        );
        try (Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/car_rental", "root", "");
             PreparedStatement pst = con.prepareStatement(
                     "INSERT INTO booking (name, permit, phone, email, address, gender, brand, model, duration, cost, payment) VALUES (?,?,?,?,?,?,?,?,?,?,?)")) {

            pst.setString(1, fullName);
            pst.setString(2, Id);
            pst.setString(3, Phone);
            pst.setString(4, Email);
            pst.setString(5, Address);
            pst.setString(6, Brand);
            pst.setString(7, Model);
            pst.setString(8, Gender);
            pst.setString(9, Duration);
            pst.setString(10, costs);
            pst.setString(11, payMethod);

            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Car Booked successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

            // Reset fields
            name.setText("");
            id.setText("");
            email.setText("");
            phone.setText("");
            address.setText("");
            brand.setSelectedIndex(0);
            model.setText("");
            gender.setSelectedIndex(0);
            duration.setSelectedIndex(0);
            cost.setSelectedIndex(0);
            paymethod.setSelectedIndex(0);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new carRentSystem().setVisible(true));
    }
    
}
