
package javatutmod;

public class testStudTeacher {

    public static void main(String[] args) {
        // TODO code application logic here
        student stud1 = new student("Danny", 32, "2405001032");
        
        System.out.println("Name: " + stud1.getName());
        System.out.println("Age: " + stud1.getAge());
        System.out.println("Roll: " + stud1.getRollnb());
    } 
}
