
package javatutmod;
import java.util.*;

public class currentDate {

    public static void main(String[] args) {
        // TODO code application logic here
        Date currentDate = new Date();
        
        System.out.println("The current date is " + currentDate.toString());
    }
    
}
